# apt update --assume-yes 
# apt --assume-yes install apache2 
# systemctl restart apache2
curl -sL https://deb.nodesource.com/setup_16.x | sudo bash -

mkdir -p /app/hello
cd /app/hello
git clone https://github.com/raghavan-mk/helloworld.git
cd helloworld/fe
apt --assume-yes install nodejs
apt --assume-yes install npm
npm --assume-yes install -g @angular/cli@13.0.3

rm -rf .browserslistrc
cat <<EOF > .browserslistrc
last 1 Chrome version
last 1 Firefox version
Firefox ESR
EOF

npm i
npm audit fix --force
npm i
ng build

nohup ng serve --port 80 -o --host 0.0.0.0 &

#curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
# #Download AzCopy
# wget https://aka.ms/downloadazcopy-v10-linux
 
# #Expand Archive
# tar -xvf downloadazcopy-v10-linux
 
# #(Optional) Remove existing AzCopy version
# sudo rm /usr/bin/azcopy
 
# #Move AzCopy to the destination you want to store it
# sudo cp ./azcopy_linux_amd64_*/azcopy /usr/bin/