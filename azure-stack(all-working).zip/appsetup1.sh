# apt update --assume-yes 
# apt --assume-yes install apache2 
# systemctl restart apache2
apt --assume-yes install postgresql-client
apt --assume-yes install dotnet-runtime-7.0
apt --assume-yes install dotnet-sdk-7.0

echo "CREATE TABLE MOVIE( ID int4 NOT NULL GENERATED ALWAYS AS IDENTITY, \"Name\" VARCHAR NOT NULL, \"Year\" int4 NOT NULL, genre VARCHAR NOT NULL, CONSTRAINT movie_pk PRIMARY KEY (\"Name\", \"Year\") );" > postgres.sql

echo "INSERT INTO MOVIE (\"Name\",\"Year\",genre) VALUES ('Matrix Reloaded',2022,'Action'),('Matrix',1999,'Action');" >> postgres.sql

PGPASSWORD=QazWsx123 psql --host=rbs-postgre-db-server.postgres.database.azure.com --port=5432 --dbname=moviedb --user=rbs_db_admin -a -q -f postgres.sql 

mkdir -p /app/hello
cd /app/hello
git clone https://github.com/raghavan-mk/helloworld.git
cd helloworld/api
IPADDR=ifconfig | grep inet | grep broadcast | grep -v init6 | tr -s " " | cut -d " " -f3
# nohup dotnet run --urls="http://10.0.12.3" &

nohup dotnet run --urls="http://${IPADDR}" &


#/app/hello/helloworld/api/appsettings.json  #Update the connection string here
#/app/hello/helloworld/fe/src/app/dataService.ts  #Update the apiURL with app server ip address



#curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
# #Download AzCopy
# wget https://aka.ms/downloadazcopy-v10-linux
 
# #Expand Archive
# tar -xvf downloadazcopy-v10-linux
 
# #(Optional) Remove existing AzCopy version
# sudo rm /usr/bin/azcopy
 
# #Move AzCopy to the destination you want to store it
# sudo cp ./azcopy_linux_amd64_*/azcopy /usr/bin/