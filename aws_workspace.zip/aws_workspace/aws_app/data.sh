yum update -y
yum install -y apache2


